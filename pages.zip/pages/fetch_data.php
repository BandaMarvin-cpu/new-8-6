<?php
// Step 1: Establish a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "airqo";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Step 2: Retrieve the 'type' parameter from the AJAX request
$type = $_GET['type'];

// Step 3: Query the database based on the 'type' parameter
$sql = "";
if ($type === 'printing') {
    $sql = "SELECT batchno, qty, datetime FROM printings";
} elseif ($type === 'pcbAssembly') {
    $sql = "SELECT batchno, qty, datetime  FROM pcbAssembly";
} elseif ($type === 'monitorAssembly') {
    $sql = "SELECT batchno, qty, datetime FROM monitorAssembly";
} elseif ($type === 'preDeploymentAnalysis') {
    $sql = "SELECT batchno, qty, datetime FROM preDeploymentAnalysis";
}elseif ($type === 'testing') {
    $sql = "SELECT batchno, qty, datetime FROM testing";
}
elseif ($type === 'targets') {
    $sql = "SELECT id, qty, datetime, status FROM targets";
}

$result = mysqli_query($conn, $sql);

// Step 4: Prepare the data for the JSON response
$data = array();
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = array(
            'batchno' => $row['batchno'],
            'qty' => $row['qty'],
            'datetime' => $row['datetime']
        );
    }
}

// Step 5: Close the database connection
mysqli_close($conn);

// Step 6: Return the data as a JSON response
header('Content-Type: application/json');
echo json_encode($data);
?>
