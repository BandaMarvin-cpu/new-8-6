$(document).ready( function() {
  
  
  
  $("#violin").mouseenter(function() {
    $("#violinmusic")[0].play();
});

$("#violin").mouseleave(function() {
    $("#violinmusic")[0].pause();
    $("#violinmusic")[0].currentTime=0;
});
  

  
});